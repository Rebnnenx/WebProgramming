<header class="header">  
  <div class="header__wrapper">
    <h1 class="header__heading">Art Store</h1>
    <nav class="navigation">
      <ul class="navigation__list">
        <li class="navigation__list-item"><a href="#" >Home</a></li>
        <li class="navigation__list-item"><a href="#">About</a></li>
        <li class="navigation__list-item"><a href="#">Art Works</a></li>
        <li class="navigation__list-item"><a href="#">Artists</a></li>
      </ul>
    </nav>  
  </div>
</header> 